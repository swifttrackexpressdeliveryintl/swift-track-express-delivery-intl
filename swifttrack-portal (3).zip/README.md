# Swift Track Express Delivery — Track & Trace Portal

Working logistics site with public tracking and an admin panel that creates tracking numbers.

## Demo login
- Username: `admin`
- Password: `SwiftTrack2026!`

## Sample tracking numbers
- `STEX-260913-0147` — Lagos → Los Angeles (in transit)
- `STEX-260908-0092` — Los Angeles → Lagos (delivered)
- Master AWB `071-58291364`

## Run locally
```bash
cd harborline-portal   # or the inner folder that contains server.js
node server.js
```
Open http://localhost:3000

## Deploy on Render (free)
1. Push this folder to GitHub
2. New Web Service → connect repo
3. Start command: `node server.js`
4. Plan: Free
5. Optional env vars: `ADMIN_USER`, `ADMIN_PASS`

Free instances sleep when idle; first request after sleep can take ~30s.
