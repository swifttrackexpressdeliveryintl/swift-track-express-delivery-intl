const STATUS_LABEL = {
  BOOKED: "Booked",
  COLLECTED: "Collected",
  RECEIVED: "Received at warehouse",
  EXPORT_CLEARED: "Export cleared",
  ACCEPTED: "Accepted by carrier",
  IN_TRANSIT: "In transit",
  DEPARTED: "Departed",
  ARRIVED: "Arrived destination",
  CUSTOMS: "Customs clearance",
  OUT_FOR_DELIVERY: "Out for delivery",
  DELIVERED: "Delivered",
  EXCEPTION: "Exception",
};

const EVENT_CODES = Object.keys(STATUS_LABEL);

const SEED = window.__SEED__ || { shipments: [] };
const LS_KEY = "swifttrack_shipments_v1";
const TOKEN_KEY = "swifttrack_admin_token";

let apiAlive = false;
let currentView = "home";
let currentShipment = null;

function $(sel) { return document.querySelector(sel); }
function h(html) {
  const t = document.createElement("template");
  t.innerHTML = html.trim();
  return t.content;
}

function loadLocal() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  const seed = JSON.parse(JSON.stringify(SEED));
  saveLocal(seed);
  return seed;
}

function saveLocal(db) {
  localStorage.setItem(LS_KEY, JSON.stringify(db));
}

async function probeApi() {
  try {
    const r = await fetch("/api/health", { cache: "no-store" });
    apiAlive = r.ok;
  } catch {
    apiAlive = false;
  }
  return apiAlive;
}

async function trackLookup(code) {
  const q = (code || "").trim();
  if (!q) throw new Error("Enter a tracking or air waybill number.");
  if (apiAlive) {
    const r = await fetch("/api/track/" + encodeURIComponent(q));
    if (r.ok) return r.json();
    if (r.status !== 404) throw new Error("Tracking service unavailable.");
  }
  const db = loadLocal();
  const u = q.toUpperCase().replace(/\s/g, "");
  const hit = db.shipments.find((s) =>
    s.id.toUpperCase() === u ||
    (s.hawb && s.hawb.toUpperCase() === u) ||
    (s.mawb && s.mawb.replace(/\s/g, "") === u)
  );
  if (!hit) throw new Error("No shipment matches that number.");
  return hit;
}

function token() { return localStorage.getItem(TOKEN_KEY); }

async function adminFetch(url, opts = {}) {
  const headers = Object.assign({ "Content-Type": "application/json" }, opts.headers || {});
  if (token()) headers.Authorization = "Bearer " + token();
  if (apiAlive) {
    const r = await fetch(url, Object.assign({}, opts, { headers }));
    const data = await r.json().catch(() => ({}));
    if (r.status === 401) {
      localStorage.removeItem(TOKEN_KEY);
      throw new Error("Admin session expired. Sign in again.");
    }
    if (!r.ok) throw new Error(data.error || "Request failed.");
    return data;
  }
  return localAdmin(url, opts);
}

function localAdmin(url, opts) {
  const db = loadLocal();
  const method = (opts.method || "GET").toUpperCase();
  if (url === "/api/shipments" && method === "GET") {
    return [...db.shipments].sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
  }
  if (url === "/api/shipments" && method === "POST") {
    const body = JSON.parse(opts.body || "{}");
    const id = body.id || generateTracking();
    if (db.shipments.some((s) => s.id === id)) throw new Error("Tracking number already exists.");
    const now = new Date().toISOString();
    const shipment = {
      id, hawb: id, mawb: body.mawb || generateMawb(),
      status: body.status || "BOOKED",
      service: body.service || "Priority Air Freight — Door to Door",
      incoterm: body.incoterm || "CIP",
      shipper: body.shipper || {},
      consignee: body.consignee || {},
      route: body.route || { origin: "", originName: "", destination: "", destinationName: "", via: [] },
      flights: body.flights || [],
      cargo: body.cargo || {},
      createdAt: now, updatedAt: now,
      events: [{ time: now, code: "BOOKED", title: "Tracking number issued", location: "Swift Track Control, Lagos", detail: "HAWB " + id + " created by admin." }],
    };
    db.shipments.push(shipment);
    saveLocal(db);
    return shipment;
  }
  const m = url.match(/\/api\/shipments\/([^/]+)(?:\/(events))?$/);
  if (!m) throw new Error("Unknown action.");
  const id = decodeURIComponent(m[1]);
  const shipment = db.shipments.find((s) => s.id === id);
  if (!shipment) throw new Error("Shipment not found.");
  if (m[2] === "events" && method === "POST") {
    const body = JSON.parse(opts.body || "{}");
    const ev = {
      time: body.time || new Date().toISOString(),
      code: body.code || "UPDATE",
      title: body.title || STATUS_LABEL[body.code] || "Status update",
      location: body.location || "",
      detail: body.detail || "",
    };
    shipment.events.push(ev);
    shipment.events.sort((a, b) => new Date(a.time) - new Date(b.time));
    if (body.status) shipment.status = body.status;
    else if (ev.code === "DELIVERED") shipment.status = "DELIVERED";
    else if (["DEPARTED", "ACCEPTED", "IN_TRANSIT"].includes(ev.code)) shipment.status = "IN_TRANSIT";
    else if (["ARRIVED", "CUSTOMS", "OUT_FOR_DELIVERY"].includes(ev.code)) shipment.status = ev.code;
    else if (ev.code) shipment.status = ev.code;
    shipment.updatedAt = new Date().toISOString();
    saveLocal(db);
    return shipment;
  }
  if (method === "PATCH") {
    Object.assign(shipment, JSON.parse(opts.body || {}));
    shipment.id = id;
    shipment.updatedAt = new Date().toISOString();
    saveLocal(db);
    return shipment;
  }
  if (method === "DELETE") {
    db.shipments = db.shipments.filter((s) => s.id !== id);
    saveLocal(db);
    return { ok: true };
  }
  throw new Error("Unknown action.");
}

function generateTracking() {
  const n = new Date();
  const ymd = String(n.getFullYear()).slice(2) + String(n.getMonth() + 1).padStart(2, "0") + String(n.getDate()).padStart(2, "0");
  return "STEX-" + ymd + "-" + String(Math.floor(1000 + Math.random() * 9000));
}

function generateMawb() {
  const prefixes = ["071", "932", "057", "125", "176"];
  return prefixes[Math.floor(Math.random() * prefixes.length)] + "-" + String(Math.floor(10000000 + Math.random() * 89999999));
}

function fmt(ts) {
  if (!ts) return "—";
  const d = new Date(ts);
  if (Number.isNaN(d.getTime())) return ts;
  return d.toLocaleString(undefined, { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

function pill(status) {
  return `<span class="status-pill st-${status}">${STATUS_LABEL[status] || status}</span>`;
}

function setView(name) {
  currentView = name;
  document.querySelectorAll("[data-view]").forEach((el) => {
    el.classList.toggle("hidden", el.getAttribute("data-view") !== name);
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
  syncAuthUi();
}

function syncAuthUi() {
  const inAdmin = Boolean(token()) || !apiAlive;
  // For offline mode, treat as "can open admin" after local login flag
  const localAuthed = sessionStorage.getItem("swifttrack_local_auth") === "1";
  const authed = apiAlive ? Boolean(token()) : localAuthed;
  $("#nav-admin-in").classList.toggle("hidden", !authed);
  $("#nav-admin-out").classList.toggle("hidden", authed);
  $("#btn-logout").classList.toggle("hidden", !authed);
  $("#mode-flag").textContent = apiAlive ? "Live server" : "Browser vault (no server)";
}

function renderTrack(s) {
  currentShipment = s;
  const events = [...(s.events || [])].sort((a, b) => new Date(b.time) - new Date(a.time));
  $("#track-result").innerHTML = `
    <div class="track-head">
      <div class="kicker">House air waybill</div>
      <div class="track-id">${s.id}</div>
      <div style="margin:10px 0 6px">${pill(s.status)}</div>
      <div class="route-strip">
        <div class="airport"><b>${s.route.origin || "—"}</b><span>${s.route.originName || ""}</span></div>
        <div class="route-line"></div>
        <div class="airport"><b>${s.route.destination || "—"}</b><span>${s.route.destinationName || ""}</span></div>
      </div>
      <div class="meta-grid">
        <div class="meta"><label>Master AWB</label><div class="mono">${s.mawb || "—"}</div></div>
        <div class="meta"><label>Service</label><div>${s.service || "—"}</div></div>
        <div class="meta"><label>Incoterm</label><div>${s.incoterm || "—"}</div></div>
        <div class="meta"><label>Last update</label><div>${fmt(s.updatedAt)}</div></div>
        <div class="meta"><label>Pieces / weight</label><div>${s.cargo.pieces || "—"} pcs · ${s.cargo.grossKg || "—"} kg</div></div>
        <div class="meta"><label>Chargeable / volume</label><div>${s.cargo.chargeableKg || "—"} kg · ${s.cargo.volumeCbm || "—"} cbm</div></div>
      </div>
    </div>
    <div class="panel">
      <div class="kicker">Movement history</div>
      <h2 style="margin-bottom:14px">Checkpoints</h2>
      <div class="timeline">
        ${events.map((e) => `
          <div class="event">
            <time>${fmt(e.time)}</time>
            <h4>${e.title || STATUS_LABEL[e.code] || e.code}</h4>
            <p>${e.location || ""}</p>
            <p>${e.detail || ""}</p>
          </div>
        `).join("")}
      </div>
    </div>
    <div class="cards">
      <div class="card">
        <div class="kicker">Shipper</div>
        <h3>${s.shipper.name || "—"}</h3>
        <p>${s.shipper.contact || ""}<br>${s.shipper.address || ""}<br>${s.shipper.phone || ""}<br>${s.shipper.email || ""}</p>
      </div>
      <div class="card">
        <div class="kicker">Consignee</div>
        <h3>${s.consignee.name || "—"}</h3>
        <p>${s.consignee.contact || ""}<br>${s.consignee.address || ""}<br>${s.consignee.phone || ""}<br>${s.consignee.email || ""}</p>
      </div>
      <div class="card">
        <div class="kicker">Cargo</div>
        <h3>${s.cargo.packaging || "General cargo"}</h3>
        <p>${s.cargo.description || ""}</p>
        <p style="margin-top:8px">Declared value USD ${Number(s.cargo.declaredValueUsd || 0).toLocaleString()}</p>
      </div>
    </div>
    ${(s.flights && s.flights.length) ? `
      <div class="panel" style="margin-top:16px">
        <div class="kicker">Planned routing</div>
        <table>
          <thead><tr><th>Flight</th><th>From</th><th>To</th><th>ETD</th><th>ETA</th></tr></thead>
          <tbody>${s.flights.map((f) => `<tr><td class="mono">${f.flight}</td><td>${f.from}</td><td>${f.to}</td><td>${fmt(f.etd)}</td><td>${fmt(f.eta)}</td></tr>`).join("")}</tbody>
        </table>
      </div>` : ""}
  `;
  setView("track");
}

async function doTrack(code) {
  const box = $("#track-error");
  box.classList.add("hidden");
  try {
    const s = await trackLookup(code);
    history.replaceState(null, "", "#/track/" + encodeURIComponent(s.id));
    renderTrack(s);
  } catch (err) {
    box.textContent = err.message;
    box.classList.remove("hidden");
    setView("home");
  }
}

function partyFields(prefix, data = {}) {
  return `
    <div class="field"><label>${prefix} name</label><input name="${prefix}_name" value="${data.name || ""}" required></div>
    <div class="field"><label>${prefix} contact</label><input name="${prefix}_contact" value="${data.contact || ""}"></div>
    <div class="field"><label>${prefix} phone</label><input name="${prefix}_phone" value="${data.phone || ""}"></div>
    <div class="field"><label>${prefix} email</label><input name="${prefix}_email" value="${data.email || ""}"></div>
    <div class="field" style="grid-column:1/-1"><label>${prefix} address</label><textarea name="${prefix}_address">${data.address || ""}</textarea></div>
  `;
}

function fillCreateForm(prefillId) {
  const id = prefillId || generateTracking();
  $("#create-form-wrap").innerHTML = `
    <form id="create-form" class="panel">
      <div class="kicker">Issue house air waybill</div>
      <h2>Create tracking number</h2>
      <div class="form-grid" style="margin-top:16px">
        <div class="field"><label>Tracking / HAWB</label><input name="id" class="mono" value="${id}" required></div>
        <div class="field"><label>Master AWB (optional)</label><input name="mawb" class="mono" placeholder="Auto if blank"></div>
        <div class="field"><label>Service</label>
          <select name="service">
            <option>Priority Air Freight — Door to Door</option>
            <option>Express Air — Airport to Door</option>
            <option>Standard Air Freight</option>
            <option>Sea Freight LCL</option>
            <option>Road haulage — West Africa</option>
          </select>
        </div>
        <div class="field"><label>Incoterm</label>
          <select name="incoterm">
            <option>CIP</option><option>CIF</option><option>DAP</option><option>DDP</option>
            <option>FOB</option><option>EXW</option><option>FCA</option>
          </select>
        </div>
        <div class="field"><label>Origin IATA</label><input name="origin" placeholder="LOS" required></div>
        <div class="field"><label>Origin name</label><input name="originName" placeholder="Murtala Muhammed Int'l, Lagos"></div>
        <div class="field"><label>Destination IATA</label><input name="destination" placeholder="LAX" required></div>
        <div class="field"><label>Destination name</label><input name="destinationName" placeholder="Los Angeles Int'l"></div>
        <div class="field"><label>Pieces</label><input name="pieces" type="number" min="1" value="1"></div>
        <div class="field"><label>Gross kg</label><input name="grossKg" type="number" step="0.1"></div>
        <div class="field"><label>Chargeable kg</label><input name="chargeableKg" type="number" step="0.1"></div>
        <div class="field"><label>Volume cbm</label><input name="volumeCbm" type="number" step="0.01"></div>
        <div class="field"><label>Packaging</label><input name="packaging" placeholder="Flight cases"></div>
        <div class="field"><label>Declared value USD</label><input name="declaredValueUsd" type="number" step="1"></div>
        <div class="field" style="grid-column:1/-1"><label>Cargo description</label><textarea name="description" placeholder="Nature and quantity of goods"></textarea></div>
        ${partyFields("shipper")}
        ${partyFields("consignee")}
      </div>
      <div style="margin-top:16px; display:flex; gap:8px; flex-wrap:wrap">
        <button class="btn btn-gold" type="submit">Issue tracking number</button>
        <button class="btn btn-ghost" type="button" id="btn-cancel-create">Cancel</button>
      </div>
    </form>
  `;
  $("#btn-cancel-create").onclick = () => showAdminList();
  $("#create-form").onsubmit = submitCreate;
}

function formVal(form, name) { return (form.elements[name] && form.elements[name].value) || ""; }

async function submitCreate(e) {
  e.preventDefault();
  const f = e.target;
  const payload = {
    id: formVal(f, "id").trim().toUpperCase(),
    mawb: formVal(f, "mawb").trim(),
    service: formVal(f, "service"),
    incoterm: formVal(f, "incoterm"),
    status: "BOOKED",
    route: {
      origin: formVal(f, "origin").toUpperCase(),
      originName: formVal(f, "originName"),
      destination: formVal(f, "destination").toUpperCase(),
      destinationName: formVal(f, "destinationName"),
      via: [],
    },
    cargo: {
      pieces: Number(formVal(f, "pieces") || 0),
      grossKg: Number(formVal(f, "grossKg") || 0),
      chargeableKg: Number(formVal(f, "chargeableKg") || 0),
      volumeCbm: Number(formVal(f, "volumeCbm") || 0),
      packaging: formVal(f, "packaging"),
      description: formVal(f, "description"),
      declaredValueUsd: Number(formVal(f, "declaredValueUsd") || 0),
    },
    shipper: {
      name: formVal(f, "shipper_name"),
      contact: formVal(f, "shipper_contact"),
      phone: formVal(f, "shipper_phone"),
      email: formVal(f, "shipper_email"),
      address: formVal(f, "shipper_address"),
    },
    consignee: {
      name: formVal(f, "consignee_name"),
      contact: formVal(f, "consignee_contact"),
      phone: formVal(f, "consignee_phone"),
      email: formVal(f, "consignee_email"),
      address: formVal(f, "consignee_address"),
    },
  };
  try {
    const created = await adminFetch("/api/shipments", { method: "POST", body: JSON.stringify(payload) });
    await showAdminDetail(created.id, "Tracking number issued: " + created.id);
  } catch (err) {
    alert(err.message);
  }
}

async function showAdminList(msg) {
  setView("admin");
  $("#admin-msg").classList.toggle("hidden", !msg);
  if (msg) $("#admin-msg").textContent = msg;
  const list = await adminFetch("/api/shipments");
  $("#admin-body").innerHTML = `
    <div class="toolbar">
      <div>
        <div class="kicker">Control tower</div>
        <h2>Shipments</h2>
      </div>
      <button class="btn btn-gold" id="btn-new">+ Create tracking number</button>
    </div>
    <div class="panel" style="padding:0; overflow:auto">
      <table>
        <thead><tr><th>HAWB</th><th>Route</th><th>Status</th><th>Updated</th></tr></thead>
        <tbody>
          ${list.map((s) => `
            <tr class="clickable" data-id="${s.id}">
              <td class="mono"><b>${s.id}</b><br><span style="color:var(--muted)">${s.mawb || ""}</span></td>
              <td>${s.route.origin || "—"} → ${s.route.destination || "—"}<br><span style="color:var(--muted)">${s.shipper.name || ""}</span></td>
              <td>${pill(s.status)}</td>
              <td>${fmt(s.updatedAt)}</td>
            </tr>`).join("") || `<tr><td colspan="4">No shipments yet.</td></tr>`}
        </tbody>
      </table>
    </div>
  `;
  $("#btn-new").onclick = () => { fillCreateForm(); setView("create"); };
  $("#admin-body").querySelectorAll("tr[data-id]").forEach((row) => {
    row.onclick = () => showAdminDetail(row.getAttribute("data-id"));
  });
}

async function showAdminDetail(id, msg) {
  const list = await adminFetch("/api/shipments");
  const s = list.find((x) => x.id === id) || await trackLookup(id);
  currentShipment = s;
  setView("admin");
  $("#admin-msg").classList.toggle("hidden", !msg);
  if (msg) $("#admin-msg").textContent = msg;
  const events = [...(s.events || [])].sort((a, b) => new Date(b.time) - new Date(a.time));
  $("#admin-body").innerHTML = `
    <div class="toolbar">
      <button class="btn btn-ghost" id="btn-back">← All shipments</button>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn btn-ghost" id="btn-public">View public track</button>
        <button class="btn btn-ghost" id="btn-delete">Void number</button>
      </div>
    </div>
    <div class="waybill">
      <div class="waybill-top">
        <div>
          <div class="kicker">Swift Track Express Delivery Ltd</div>
          <div class="track-id">${s.id}</div>
          <div class="mono">MAWB ${s.mawb || "—"}</div>
        </div>
        <div style="text-align:right">${pill(s.status)}<div class="barcode">*${s.id}*</div></div>
      </div>
      <div class="meta-grid">
        <div class="meta"><label>Shipper</label><div>${s.shipper.name || ""}<br>${s.shipper.address || ""}</div></div>
        <div class="meta"><label>Consignee</label><div>${s.consignee.name || ""}<br>${s.consignee.address || ""}</div></div>
      </div>
    </div>
    <form id="scan-form" class="panel" style="margin-top:16px">
      <div class="kicker">Add scan</div>
      <h2>Post a checkpoint</h2>
      <div class="form-grid">
        <div class="field"><label>Event</label>
          <select name="code">${EVENT_CODES.map((c) => `<option value="${c}">${STATUS_LABEL[c]}</option>`).join("")}</select>
        </div>
        <div class="field"><label>When</label><input type="datetime-local" name="time"></div>
        <div class="field"><label>Location</label><input name="location" placeholder="MMIA Cargo, Lagos" required></div>
        <div class="field"><label>Title override</label><input name="title" placeholder="Optional"></div>
        <div class="field" style="grid-column:1/-1"><label>Detail</label><textarea name="detail" placeholder="What happened"></textarea></div>
      </div>
      <button class="btn btn-navy" type="submit" style="margin-top:12px">Post scan</button>
    </form>
    <div class="panel">
      <div class="kicker">History</div>
      <div class="timeline">
        ${events.map((e) => `<div class="event"><time>${fmt(e.time)}</time><h4>${e.title}</h4><p>${e.location || ""}</p><p>${e.detail || ""}</p></div>`).join("")}
      </div>
    </div>
  `;
  $("#btn-back").onclick = () => showAdminList();
  $("#btn-public").onclick = () => { history.replaceState(null, "", "#/track/" + s.id); renderTrack(s); };
  $("#btn-delete").onclick = async () => {
    if (!confirm("Void " + s.id + "?")) return;
    await adminFetch("/api/shipments/" + encodeURIComponent(s.id), { method: "DELETE" });
    showAdminList("Tracking number voided.");
  };
  const timeInput = $("#scan-form").elements.time;
  const iso = new Date();
  iso.setMinutes(iso.getMinutes() - iso.getTimezoneOffset());
  timeInput.value = iso.toISOString().slice(0, 16);
  $("#scan-form").onsubmit = async (ev) => {
    ev.preventDefault();
    const f = ev.target;
    const code = formVal(f, "code");
    const local = formVal(f, "time");
    await adminFetch("/api/shipments/" + encodeURIComponent(s.id) + "/events", {
      method: "POST",
      body: JSON.stringify({
        code,
        status: code,
        title: formVal(f, "title") || STATUS_LABEL[code],
        location: formVal(f, "location"),
        detail: formVal(f, "detail"),
        time: local ? new Date(local).toISOString() : new Date().toISOString(),
      }),
    });
    showAdminDetail(s.id, "Scan posted.");
  };
}

async function handleLogin(e) {
  e.preventDefault();
  const username = formVal(e.target, "username");
  const password = formVal(e.target, "password");
  $("#login-error").classList.add("hidden");
  try {
    if (apiAlive) {
      const r = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "Login failed");
      localStorage.setItem(TOKEN_KEY, data.token);
    } else {
      if (username !== "admin" || password !== "SwiftTrack2026!") {
        throw new Error("Invalid admin credentials.");
      }
      sessionStorage.setItem("swifttrack_local_auth", "1");
    }
    syncAuthUi();
    await showAdminList();
  } catch (err) {
    $("#login-error").textContent = err.message;
    $("#login-error").classList.remove("hidden");
  }
}

function logout() {
  localStorage.removeItem(TOKEN_KEY);
  sessionStorage.removeItem("swifttrack_local_auth");
  syncAuthUi();
  setView("home");
}

function requireAdmin() {
  const localAuthed = sessionStorage.getItem("swifttrack_local_auth") === "1";
  if (apiAlive && !token()) { setView("login"); return false; }
  if (!apiAlive && !localAuthed) { setView("login"); return false; }
  return true;
}

function route() {
  const hash = location.hash || "#/";
  const parts = hash.replace(/^#\//, "").split("/");
  if (parts[0] === "track" && parts[1]) return doTrack(decodeURIComponent(parts[1]));
  if (parts[0] === "admin") {
    if (!requireAdmin()) return;
    return showAdminList();
  }
  if (parts[0] === "login") return setView("login");
  if (parts[0] === "support") return setView("support");
  setView("home");
}

window.addEventListener("hashchange", route);

document.addEventListener("DOMContentLoaded", async () => {
  await probeApi();
  if (!localStorage.getItem(LS_KEY)) saveLocal(JSON.parse(JSON.stringify(SEED)));
  syncAuthUi();
  $("#home-track-form").onsubmit = (e) => {
    e.preventDefault();
    const code = formVal(e.target, "code");
    location.hash = "#/track/" + encodeURIComponent(code.trim());
  };
  $("#login-form").onsubmit = handleLogin;
  $("#nav-track").onclick = () => { location.hash = "#/"; };
  const navSupport = $("#nav-support");
  if (navSupport) navSupport.onclick = () => { location.hash = "#/support"; };
  $("#nav-admin-out").onclick = () => { location.hash = "#/login"; };
  $("#nav-admin-in").onclick = () => { location.hash = "#/admin"; };
  $("#btn-logout").onclick = logout;
  const sf = $("#support-form");
  if (sf) sf.onsubmit = handleSupportSubmit;
  initLiveChat();
  route();
});

async function handleSupportSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const err = $("#support-error");
  const ok = $("#support-ok");
  if (err) { err.classList.add("hidden"); err.textContent = ""; }
  if (ok) { ok.classList.add("hidden"); ok.textContent = ""; }
  const payload = {
    name: formVal(form, "name"),
    email: formVal(form, "email"),
    phone: formVal(form, "phone"),
    hawb: formVal(form, "hawb"),
    topic: formVal(form, "topic"),
    message: formVal(form, "message"),
  };
  try {
    let result;
    if (apiAlive) {
      result = await api("POST", "/api/support", payload);
    } else {
      const ticketId = "ST-" + Date.now().toString().slice(-8);
      const list = JSON.parse(localStorage.getItem("swifttrack_support_v1") || "[]");
      list.unshift(Object.assign({ id: ticketId, createdAt: new Date().toISOString(), status: "OPEN" }, payload));
      localStorage.setItem("swifttrack_support_v1", JSON.stringify(list));
      // Official-looking mailto fallback when no server email config
      const subject = encodeURIComponent("[Swift Track Support] " + ticketId);
      const body = encodeURIComponent(
        "Ticket: " + ticketId + "\nName: " + payload.name + "\nEmail: " + payload.email +
        "\nPhone: " + (payload.phone || "—") + "\nHAWB: " + (payload.hawb || "—") +
        "\nTopic: " + payload.topic + "\n\n" + payload.message
      );
      result = {
        ticketId,
        message: "Ticket " + ticketId + " saved. Opening your email app to send the official copy…",
        mailto: "mailto:support@swifttrack.example?subject=" + subject + "&body=" + body,
      };
      if (result.mailto) setTimeout(() => { location.href = result.mailto; }, 600);
    }
    if (ok) {
      ok.textContent = result.message || ("Ticket " + result.ticketId + " created. Our desk will reply by email.");
      ok.classList.remove("hidden");
    }
    form.reset();
  } catch (ex) {
    if (err) {
      err.textContent = (ex && ex.error) || ex.message || "Could not submit. Try again or call +234 809 220 4410.";
      err.classList.remove("hidden");
    }
  }
}

function initLiveChat() {
  if (document.getElementById("st-chat-launcher")) return;
  const launcher = document.createElement("button");
  launcher.id = "st-chat-launcher";
  launcher.type = "button";
  launcher.title = "Live support";
  launcher.textContent = "Chat";
  const panel = document.createElement("div");
  panel.id = "st-chat-panel";
  panel.innerHTML = `
    <div class="st-chat-head">
      <div><strong>Swift Track Support</strong><span>Usually replies in under a minute</span></div>
      <button type="button" id="st-chat-close" aria-label="Close">×</button>
    </div>
    <div class="st-chat-body" id="st-chat-body"></div>
    <div class="st-chat-foot">
      <input id="st-chat-input" placeholder="Type your message…" autocomplete="off" />
      <button type="button" id="st-chat-send">Send</button>
    </div>`;
  document.body.appendChild(launcher);
  document.body.appendChild(panel);

  const body = () => document.getElementById("st-chat-body");
  function addBubble(text, who) {
    const d = document.createElement("div");
    d.className = "st-bubble " + who;
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, "0");
    const mm = String(now.getMinutes()).padStart(2, "0");
    const safe = who === "agent" ? text : text.replace(/</g, "&lt;");
    d.innerHTML = safe + '<span class="meta">' + (who === "agent" ? "Support · " : "You · ") + hh + ":" + mm + "</span>";
    body().appendChild(d);
    body().scrollTop = body().scrollHeight;
  }

  addBubble("Hello — you are connected to <b>Swift Track Express Delivery</b> support. Share your HAWB (e.g. STEX-…) and how we can help.", "agent");

  launcher.onclick = () => panel.classList.toggle("open");
  document.getElementById("st-chat-close").onclick = () => panel.classList.remove("open");

  function agentReply(userText) {
    const t = userText.toLowerCase();
    let reply;
    if (/stex-|hawb|tracking|where|status/.test(t)) {
      reply = "Please paste your full HAWB (STEX-……). I will pull the latest scan from the control tower.";
    } else if (/deliver|pod|address|lagos|lekki|vi\b/.test(t)) {
      reply = "For delivery windows in Lagos, send preferred date, site contact name and phone. Ops will confirm within the hour during desk hours.";
    } else if (/claim|damage|missing|shortage/.test(t)) {
      reply = "Sorry about that. Email photos + HAWB to support@swifttrack.example or open a ticket on the Support page. Claims should be filed within 7 days of POD.";
    } else if (/hello|hi\b|hey/.test(t)) {
      reply = "Hi — how can we help with your shipment today?";
    } else {
      reply = "Thanks. A specialist can also follow up by email. Use the Support page form for an official ticket reference, or call +234 809 220 4410.";
    }
    setTimeout(() => addBubble(reply, "agent"), 600 + Math.random() * 800);
  }

  function sendChat() {
    const input = document.getElementById("st-chat-input");
    const text = (input.value || "").trim();
    if (!text) return;
    addBubble(text.replace(/</g, "&lt;"), "me");
    input.value = "";
    agentReply(text);
  }
  document.getElementById("st-chat-send").onclick = sendChat;
  document.getElementById("st-chat-input").addEventListener("keydown", (ev) => {
    if (ev.key === "Enter") { ev.preventDefault(); sendChat(); }
  });
}

