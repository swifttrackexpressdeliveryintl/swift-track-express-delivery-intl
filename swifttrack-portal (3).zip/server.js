const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");

const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASS = process.env.ADMIN_PASS || "SwiftTrack2026!";
const PUBLIC = path.join(__dirname, "public");
const DATA_FILE = path.join(__dirname, "data", "shipments.json");
const SUPPORT_FILE = path.join(__dirname, "data", "support-tickets.json");
const SUPPORT_EMAIL = process.env.SUPPORT_EMAIL || process.env.EMAIL_TO || "";
const WEB3FORMS_KEY = process.env.WEB3FORMS_KEY || "";
const RESEND_API_KEY = process.env.RESEND_API_KEY || "";

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
};

const sessions = new Map();

function loadDb() {
  try {
    const parsed = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    if (!Array.isArray(parsed.shipments)) parsed.shipments = [];
    return parsed;
  } catch {
    return { shipments: [] };
  }
}

function saveDb(db) {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}

function send(res, status, body, headers) {
  const payload = typeof body === "string" || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(status, Object.assign({ "Content-Type": "application/json; charset=utf-8" }, headers || {}));
  res.end(payload);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => {
      const raw = Buffer.concat(chunks).toString("utf8");
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); }
      catch { reject(new Error("Invalid JSON")); }
    });
    req.on("error", reject);
  });
}

function isAuthed(req) {
  const header = req.headers.authorization || "";
  const token = header.replace(/^Bearer\s+/i, "");
  return Boolean(token && sessions.has(token));
}

function generateTracking() {
  const n = new Date();
  const ymd = String(n.getFullYear()).slice(2) + String(n.getMonth() + 1).padStart(2, "0") + String(n.getDate()).padStart(2, "0");
  return "STEX-" + ymd + "-" + String(Math.floor(1000 + Math.random() * 9000));
}

function generateMawb() {
  const prefixes = ["071", "932", "057", "125", "176"];
  return prefixes[Math.floor(Math.random() * prefixes.length)] + "-" + String(Math.floor(10000000 + Math.random() * 89999999));
}

function findShipment(db, code) {
  const u = String(code || "").trim().toUpperCase().replace(/\s/g, "");
  return db.shipments.find((s) =>
    s.id.toUpperCase() === u ||
    (s.hawb && s.hawb.toUpperCase() === u) ||
    (s.mawb && s.mawb.replace(/\s/g, "") === u)
  );
}

function serveStatic(res, urlPath) {
  let rel = decodeURIComponent(urlPath);
  if (rel === "/" || rel === "") rel = "/index.html";
  const filePath = path.normalize(path.join(PUBLIC, rel));
  if (!filePath.startsWith(PUBLIC)) return send(res, 403, { error: "Forbidden" });
  fs.readFile(filePath, (err, buf) => {
    if (err) {
      return fs.readFile(path.join(PUBLIC, "index.html"), (err2, html) => {
        if (err2) return send(res, 404, { error: "Not found" });
        send(res, 200, html, { "Content-Type": "text/html; charset=utf-8" });
      });
    }
    send(res, 200, buf, { "Content-Type": MIME[path.extname(filePath).toLowerCase()] || "application/octet-stream" });
  });
}

async function handleApi(req, res, url) {
  const pathname = url.pathname;
  const method = req.method;

  if (pathname === "/api/health" && method === "GET") {
    return send(res, 200, { ok: true, service: "Swift Track Portal", time: new Date().toISOString() });
  }

  if (pathname.startsWith("/api/track/") && method === "GET") {
    const code = decodeURIComponent(pathname.slice("/api/track/".length));
    const hit = findShipment(loadDb(), code);
    if (!hit) return send(res, 404, { error: "No shipment matches that number." });
    return send(res, 200, hit);
  }

  if (pathname === "/api/login" && method === "POST") {
    const body = await readBody(req);
    if (body.username === ADMIN_USER && body.password === ADMIN_PASS) {
      const token = "hl_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
      sessions.set(token, { username: body.username, at: Date.now() });
      return send(res, 200, { token, username: body.username });
    }
    return send(res, 401, { error: "Invalid admin credentials." });
  }

  if (pathname === "/api/shipments" && method === "GET") {
    if (!isAuthed(req)) return send(res, 401, { error: "Admin session required." });
    const list = [...loadDb().shipments].sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    return send(res, 200, list);
  }

  if (pathname === "/api/shipments" && method === "POST") {
    if (!isAuthed(req)) return send(res, 401, { error: "Admin session required." });
    const b = await readBody(req);
    const id = (b.id || generateTracking()).toUpperCase();
    const db = loadDb();
    if (db.shipments.some((s) => s.id === id)) return send(res, 409, { error: "Tracking number already exists." });
    const now = new Date().toISOString();
    const shipment = {
      id,
      mawb: b.mawb || generateMawb(),
      hawb: id,
      status: b.status || "BOOKED",
      service: b.service || "Priority Air Freight — Door to Door",
      incoterm: b.incoterm || "CIP",
      shipper: b.shipper || {},
      consignee: b.consignee || {},
      route: b.route || { origin: "", originName: "", destination: "", destinationName: "", via: [] },
      flights: b.flights || [],
      cargo: b.cargo || {},
      createdAt: now,
      updatedAt: now,
      events: (b.events && b.events.length) ? b.events : [{
        time: now, code: "BOOKED", title: "Tracking number issued",
        location: "Swift Track Control, Lagos", detail: "HAWB " + id + " created by admin."
      }],
    };
    db.shipments.push(shipment);
    saveDb(db);
    return send(res, 201, shipment);
  }

  const evMatch = pathname.match(/^\/api\/shipments\/([^/]+)\/events$/);
  if (evMatch && method === "POST") {
    if (!isAuthed(req)) return send(res, 401, { error: "Admin session required." });
    const id = decodeURIComponent(evMatch[1]);
    const db = loadDb();
    const shipment = db.shipments.find((s) => s.id === id);
    if (!shipment) return send(res, 404, { error: "Shipment not found." });
    const body = await readBody(req);
    const ev = {
      time: body.time || new Date().toISOString(),
      code: body.code || "UPDATE",
      title: body.title || "Status update",
      location: body.location || "",
      detail: body.detail || "",
    };
    shipment.events = shipment.events || [];
    shipment.events.push(ev);
    shipment.events.sort((a, b) => new Date(a.time) - new Date(b.time));
    if (body.status) shipment.status = body.status;
    else if (ev.code === "DELIVERED") shipment.status = "DELIVERED";
    else if (ev.code === "OUT_FOR_DELIVERY") shipment.status = "OUT_FOR_DELIVERY";
    else if (ev.code === "ARRIVED" || ev.code === "CUSTOMS") shipment.status = ev.code;
    else if (ev.code === "DEPARTED" || ev.code === "ACCEPTED") shipment.status = "IN_TRANSIT";
    shipment.updatedAt = new Date().toISOString();
    saveDb(db);
    return send(res, 200, shipment);
  }

  const idMatch = pathname.match(/^\/api\/shipments\/([^/]+)$/);
  if (idMatch && method === "PATCH") {
    if (!isAuthed(req)) return send(res, 401, { error: "Admin session required." });
    const id = decodeURIComponent(idMatch[1]);
    const db = loadDb();
    const idx = db.shipments.findIndex((s) => s.id === id);
    if (idx < 0) return send(res, 404, { error: "Shipment not found." });
    const body = await readBody(req);
    db.shipments[idx] = Object.assign({}, db.shipments[idx], body, { id, updatedAt: new Date().toISOString() });
    saveDb(db);
    return send(res, 200, db.shipments[idx]);
  }

  if (idMatch && method === "DELETE") {
    if (!isAuthed(req)) return send(res, 401, { error: "Admin session required." });
    const id = decodeURIComponent(idMatch[1]);
    const db = loadDb();
    const next = db.shipments.filter((s) => s.id !== id);
    if (next.length === db.shipments.length) return send(res, 404, { error: "Shipment not found." });
    db.shipments = next;
    saveDb(db);
    return send(res, 200, { ok: true });
  }


  if (pathname === "/api/support" && method === "POST") {
    const body = await readBody(req);
    const name = (body.name || "").trim();
    const email = (body.email || "").trim();
    const message = (body.message || "").trim();
    if (!name || !email || !message) {
      return send(res, 400, { error: "Name, email and message are required." });
    }
    const ticketId = "ST-" + new Date().toISOString().slice(2, 10).replace(/-/g, "") + "-" + String(Math.floor(1000 + Math.random() * 9000));
    const ticket = {
      id: ticketId,
      name,
      email,
      phone: (body.phone || "").trim(),
      hawb: (body.hawb || "").trim().toUpperCase(),
      topic: body.topic || "other",
      message,
      createdAt: new Date().toISOString(),
      status: "OPEN",
    };
    let tickets = [];
    try {
      tickets = JSON.parse(fs.readFileSync(SUPPORT_FILE, "utf8"));
      if (!Array.isArray(tickets)) tickets = [];
    } catch {}
    tickets.unshift(ticket);
    fs.mkdirSync(path.dirname(SUPPORT_FILE), { recursive: true });
    fs.writeFileSync(SUPPORT_FILE, JSON.stringify(tickets, null, 2));

    let emailSent = false;
    let emailNote = "Ticket saved. Configure WEB3FORMS_KEY or RESEND_API_KEY to send official email.";

    const subject = "[Swift Track Support] " + ticketId + " — " + (ticket.topic || "inquiry");
    const textBody =
      "Ticket: " + ticketId + "\n" +
      "Name: " + name + "\n" +
      "Email: " + email + "\n" +
      "Phone: " + (ticket.phone || "—") + "\n" +
      "HAWB: " + (ticket.hawb || "—") + "\n" +
      "Topic: " + ticket.topic + "\n\n" +
      message + "\n";

    try {
      if (WEB3FORMS_KEY) {
        const payload = JSON.stringify({
          access_key: WEB3FORMS_KEY,
          subject,
          from_name: "Swift Track Support Desk",
          name,
          email,
          phone: ticket.phone,
          hawb: ticket.hawb,
          topic: ticket.topic,
          message: textBody,
        });
        const https = require("https");
        await new Promise((resolve, reject) => {
          const req2 = https.request(
            { hostname: "api.web3forms.com", path: "/submit", method: "POST",
              headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(payload) } },
            (r) => { r.on("data", () => {}); r.on("end", resolve); }
          );
          req2.on("error", reject);
          req2.write(payload);
          req2.end();
        });
        emailSent = true;
        emailNote = "Official notification sent via Web3Forms.";
      } else if (RESEND_API_KEY && SUPPORT_EMAIL) {
        const https = require("https");
        const payload = JSON.stringify({
          from: "Swift Track Support <onboarding@resend.dev>",
          to: [SUPPORT_EMAIL],
          reply_to: email,
          subject,
          text: textBody,
        });
        await new Promise((resolve, reject) => {
          const req2 = https.request(
            { hostname: "api.resend.com", path: "/emails", method: "POST",
              headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + RESEND_API_KEY,
                "Content-Length": Buffer.byteLength(payload),
              } },
            (r) => { r.on("data", () => {}); r.on("end", resolve); }
          );
          req2.on("error", reject);
          req2.write(payload);
          req2.end();
        });
        emailSent = true;
        emailNote = "Official email sent to " + SUPPORT_EMAIL + ".";
      }
    } catch (e) {
      emailNote = "Ticket saved. Email send failed: " + (e.message || "error");
    }

    return send(res, 201, {
      ok: true,
      ticketId,
      emailSent,
      message: "Support ticket " + ticketId + " created. " + emailNote,
    });
  }

  return send(res, 404, { error: "Unknown API route." });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://localhost");
    if (url.pathname.startsWith("/api/")) return await handleApi(req, res, url);
    return serveStatic(res, url.pathname);
  } catch (err) {
    return send(res, 500, { error: err.message || "Server error" });
  }
});

server.listen(PORT, () => {
  console.log("Swift Track portal running on http://localhost:" + PORT);
});
