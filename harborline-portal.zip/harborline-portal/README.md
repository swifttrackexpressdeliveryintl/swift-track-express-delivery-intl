# Harborline West Africa — Track & Trace Portal

Realistic shipping logistics site with:

- Public track-and-trace (HAWB / Master AWB)
- Admin control tower to **create tracking numbers**
- Scan / checkpoint posting
- Sample production freight for Keanu Reeves Team Management

Works two ways:

1. **Free static site** (GitHub Pages, Netlify, Render Static Site) — data lives in the browser
2. **Free Render Web Service** — Node API writes `data/shipments.json`

## Default staff login

- Username: `admin`
- Password: `Harborline2026!`

Change these on Render with `ADMIN_USER` and `ADMIN_PASS`.

## Sample tracking numbers

- `HLWA-260913-0147` — Lagos → Los Angeles (in transit)
- `HLWA-260908-0092` — Los Angeles → Lagos (delivered)
- Master AWB `071-58291364`

## Run on your computer

```bash
cd harborline-portal
npm install
npm start
```

Open http://localhost:3000

## Deploy free on Render

1. Push this folder to a GitHub repository.
2. Go to [https://render.com](https://render.com) and sign in.
3. **New → Web Service** → connect the repo.
4. Settings:
   - Runtime: Node
   - Build command: `npm install`
   - Start command: `npm start`
   - Instance: **Free**
5. Add environment variables:
   - `ADMIN_USER` = `admin`
   - `ADMIN_PASS` = a password you choose
6. Deploy. Render gives you a URL like `https://harborline-portal.onrender.com`.

Free web services on Render sleep after inactivity. The first request after sleep can take ~30 seconds.

**Note:** the free disk is ephemeral. Created tracking numbers reset when the instance is rebuilt. For a permanent store later, add a paid disk or a free MongoDB/Postgres addon.

## Deploy as a static site (also free)

Upload the `public/` folder to:

- Render → New Static Site
- Netlify drag-and-drop
- GitHub Pages

Admin still works. Shipments are stored in that browser’s local storage.

## Create a tracking number

1. Open **Staff login**
2. Sign in
3. Click **Create tracking number**
4. Fill shipper, consignee, route and cargo
5. Issue the HAWB
6. Open the shipment and **Post a scan** as it moves
